
import streamlit as st
import requests
from datetime import datetime

# Load API keys from Streamlit secrets
COINSPOT_API_KEY = st.secrets.get("coinspot_api_key", "")
COINSPOT_SECRET_KEY = st.secrets.get("coinspot_secret_key", "")
CRYPTOCOM_API_KEY = st.secrets.get("crypto_com_api_key", "")
CRYPTOCOM_SECRET_KEY = st.secrets.get("crypto_com_secret_key", "")
COINBASE_API_KEY = st.secrets.get("coinbase_api_key", "")
COINBASE_SECRET_KEY = st.secrets.get("coinbase_secret_key", "")
KRAKEN_API_KEY = st.secrets.get("kraken_api_key", "")
KRAKEN_SECRET_KEY = st.secrets.get("kraken_secret_key", "")
INDEPENDENT_RESERVE_API_KEY = st.secrets.get("independent_reserve_api_key", "")
INDEPENDENT_RESERVE_SECRET_KEY = st.secrets.get("independent_reserve_secret_key", "")

st.set_page_config(page_title="🔐 Secure Crypto Arbitrage Scanner", layout="wide")
st.markdown("<h1 style='text-align: center;'>🔐 Live Arbitrage Scanner with API Keys</h1>", unsafe_allow_html=True)

st.success("✅ Your API keys have been securely loaded. Now ready for real-time authenticated data fetching.")

# Example view for verification
st.write("CoinSpot API Key:", "✅ Loaded" if COINSPOT_API_KEY else "❌ Missing")
st.write("Crypto.com API Key:", "✅ Loaded" if CRYPTOCOM_API_KEY else "❌ Missing")
st.write("Coinbase API Key:", "✅ Loaded" if COINBASE_API_KEY else "❌ Missing")
st.write("Kraken API Key:", "✅ Loaded" if KRAKEN_API_KEY else "❌ Missing")
st.write("Independent Reserve API Key:", "✅ Loaded" if INDEPENDENT_RESERVE_API_KEY else "❌ Missing")
